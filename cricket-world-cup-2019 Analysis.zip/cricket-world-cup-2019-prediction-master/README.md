# cricket-world-cup-2019-prediction
Predicting the winner of the 2019 cricket world cup using machine learning models and extracting the required data from html webpages.
